
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv('sales_data.csv')

print(df.head())

# Total sales by product
product_sales = df.groupby('Product')['Sales'].sum()
print(product_sales)

product_sales.plot(kind='bar')
plt.title('Total Sales by Product')
plt.show()
