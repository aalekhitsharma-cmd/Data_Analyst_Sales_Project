
# Sales Data Analysis Project

## Objective
Analyze sales data to identify trends, top products, and regional performance.

## Tools Used
- Python
- Pandas
- Matplotlib
- Excel

## Key Insights
- Laptops generated the highest revenue
- North region performed best
- Sales remained consistent across months

## How to Run
1. Install Python
2. Run: python analysis.py
